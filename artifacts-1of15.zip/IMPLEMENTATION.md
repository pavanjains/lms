# Robotics LMS — Implementation Backlog

## Baseline

Implementation plan for the approved Django/PostgreSQL LMS: one owner, five instructors, 25 students; shared center devices; individual student credentials; class-scoped instructor access; Essential through Grade 4 and Prime Grades 4–8; immutable lesson versions; instructor-controlled progress and feedback.

This is a proposed work breakdown, not a delivery commitment. Tickets are designed for roughly half a day to two focused developer days; split a ticket if discovery exceeds that range. Security review, MFA, shared-device handling, and recovery may require additional specialist work. No hosting prices or delivery dates are assumed.

## Tracking conventions

- Status: `TODO` → `READY` → `IN_PROGRESS` → `REVIEW` → `DONE`; use `BLOCKED` with a reason when needed.
- Every ticket initially has status `TODO` and owner `Unassigned`. Dependencies are completion gates, not a required single-threaded execution order.
- A ticket is ready when its dependencies, permission rules, required configuration, and test fixtures are available.
- Definition of done: implementation and migrations reviewed; applicable automated tests pass; authorization and error paths covered; documentation updated; acceptance evidence attached; no secrets committed.
- Record review links, test evidence, and operational approval beside each ticket when executing this backlog.
- Ticket IDs are stable; refer to IDs rather than renumbering completed work.

## Milestone gates

| Gate | Completion criteria |
|---|---|
| M1: Identity and classes | T001–T018 complete; class-scoped access and student switching verified |
| M2: Assignable lessons | T019–T031 complete; private versioned materials and repeat-safe assignments verified |
| M3: Classroom MVP | T032–T043 complete; progress, feedback, student screens, reporting verified |
| M4: Production release | T044–T052 complete; restore, UAT, security and operational approvals recorded |

Milestone numbering groups deliverables; infrastructure and policy work should begin earlier where dependencies allow.

## Epic 1: Foundation

### T001 — Initialize application repository

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: None
- Work: Create Django project, dependency lockfile, application modules, and example environment configuration.
- Acceptance: A clean checkout starts locally using documented commands; no secrets are committed.
- Evidence / PR: Pending

### T002 — Configure development services

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T001
- Work: Add local PostgreSQL and private object-storage-compatible development configuration.
- Acceptance: Application connects to both services; service data persists across restarts.
- Evidence / PR: Pending

### T003 — Set up automated checks

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T001
- Work: Configure formatting, linting, unit test execution, and CI.
- Acceptance: A pull request runs all checks; a deliberately failing test fails CI.
- Evidence / PR: Pending

### T004 — Create configuration decision register

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T001
- Work: Record proposed session timeouts, upload limits/types, retention, hosting, and recovery targets with owner/status fields.
- Acceptance: Unapproved values are marked proposed; approval blockers are identified.
- Evidence / PR: Pending

### T005 — Create base layout and error pages

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T001
- Work: Implement shared templates, role navigation placeholders, accessible form components, and error pages.
- Acceptance: Layouts work on target classroom viewports; errors do not expose debug information.
- Evidence / PR: Pending

## Epic 2: Identity and authorization

### T006 — Implement organization and user models

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T001,T002
- Work: Create custom user, organization, role, active state, and student profile including grade; add migrations before account-dependent modules.
- Acceptance: Username/email rules are explicit; student email is optional; Grade 4 does not force a kit.
- Evidence / PR: Pending

### T007 — Implement owner bootstrap

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T006
- Work: Add secure management command to create the initial organization and owner.
- Acceptance: Bootstrap is repeat-safe; credentials are not logged; no default production password exists.
- Evidence / PR: Pending

### T008 — Integrate staff authentication and MFA

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T006
- Work: Select established authentication components and implement staff login, MFA enrollment, recovery, and protected owner operations.
- Acceptance: Staff cannot access protected pages without required MFA; recovery is tested; no custom cryptography.
- Evidence / PR: Pending

### T009 — Implement instructor invitation lifecycle

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T007,T008
- Work: Build owner invitation, activation, expiry, resend, and instructor deactivation flows.
- Acceptance: Expired/reused tokens fail; deactivated instructors lose application access and active sessions.
- Evidence / PR: Pending

### T010 — Implement student credentials and resets

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T006
- Work: Build student username/password generation, private initial delivery, instructor reset, and account disable actions.
- Acceptance: No email required; old credentials and sessions fail after reset; passwords are never retrievable.
- Evidence / PR: Pending

### T011 — Implement shared-device sessions

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T004,T008,T010
- Work: Implement login/logout, switch-student action, idle/absolute expiry, protected-page cache policy, and server-side session invalidation.
- Acceptance: Logout invalidates server access; switching clears rendered protected state; expiry is tested; downloads/external sites are not claimed to be erased.
- Evidence / PR: Pending

### T012 — Add authorization service and role guards

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T006
- Work: Create reusable server-side organization/role checks and a permission matrix with class-scope integration points.
- Acceptance: Unauthenticated, inactive, wrong-role, and cross-organization requests fail consistently; no client-supplied role is trusted.
- Evidence / PR: Pending

## Epic 3: Classes and enrollment

### T013 — Implement class and membership schema

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T006
- Work: Create Class, ClassInstructor, and historical Enrollment models with constraints and indexes.
- Acceptance: Multiple instructors and classes per student are supported; overlapping duplicate active enrollment is prevented.
- Evidence / PR: Pending

### T014 — Build owner class administration

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T009,T012,T013
- Work: Build class create/edit/archive and instructor assignment/removal screens.
- Acceptance: Only owner can change teaching assignments; archived classes preserve history.
- Evidence / PR: Pending

### T015 — Complete class-scoped authorization

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T012,T013
- Work: Implement policies for class records, student identity management, class-specific progress, and historical access.
- Acceptance: Teaching one class never grants access to another class history; owner access remains organization-wide.
- Evidence / PR: Pending

### T016 — Build roster and enrollment actions

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T010,T014,T015
- Work: Create roster, enroll/withdraw, existing-account lookup, and authorized student creation flow.
- Acceptance: Students can join two classes without duplicate accounts; display-name matches are not automatically merged; lookup exposes minimum authorized data.
- Evidence / PR: Pending

### T017 — Handle transfer and class archival

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T016
- Work: Implement explicit withdrawal/reenrollment behavior and read-only historical views.
- Acceptance: Transfer preserves previous work; archived classes reject new work; access after withdrawal/removal follows documented policy.
- Evidence / PR: Pending

### T018 — Test identity and class boundaries

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T009,T011,T015,T016,T017
- Work: Add integration tests covering invitations, resets, class membership, student creation, and cross-class denial.
- Acceptance: Direct URL and crafted-request tests cover allowed and denied paths; session expiry/reset cases pass.
- Evidence / PR: Pending

## Epic 4: Lessons and private documents

### T019 — Implement lesson/version/resource schema

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T006
- Work: Create Lesson, immutable LessonVersion, versioned resources, kit/grade metadata, and draft/published/archive states.
- Acceptance: Published versions cannot be mutated through supported paths; grade and kit remain independent; resource history is retained.
- Evidence / PR: Pending

### T020 — Implement private storage adapter

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T002,T004,T019
- Work: Create private storage configuration, opaque object keys, and upload staging/cleanup interfaces.
- Acceptance: Objects are not publicly readable; secrets are server-only; test storage can be substituted.
- Evidence / PR: Pending

### T021 — Implement validated document upload

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T020
- Work: Apply approved type/size limits, content validation, inspection/quarantine policy, and safe filenames.
- Acceptance: Rejected/quarantined content is not downloadable; failure paths clean up staged objects; allowlist tests pass.
- Evidence / PR: Pending

### T022 — Implement authorized document retrieval

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T015,T019,T020,T021
- Work: Resolve resource associations, enforce role/class/student authorization, and provide controlled downloads.
- Acceptance: Changing resource IDs cannot reveal another class/student materials; token/URL behavior and cache headers are tested.
- Evidence / PR: Pending

### T023 — Build lesson draft editor

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T005,T019,T021
- Work: Create LEGO URL, kit, suggested grade range, description, instructions, and supporting document editor.
- Acceptance: Authorized instructors create drafts; unsafe URL schemes and unsafe rendered content are rejected; no server-side scraping is introduced.
- Evidence / PR: Pending

### T024 — Implement publishing and revision service

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T004,T023
- Work: Publish immutable versions; create a new draft for revisions; define author/editor permissions in the decision register.
- Acceptance: Existing versions and document references stay stable; instructors publish without owner approval; concurrent publication is controlled.
- Evidence / PR: Pending

### T025 — Build lesson library and detail screens

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T022,T024
- Work: Add kit/grade filters, version display, archive actions, and broken-link reporting without automatic fetching.
- Acceptance: Grade 4 supports both kits; archived lessons remain available to historical authorized assignments.
- Evidence / PR: Pending

### T026 — Test lesson and resource lifecycle

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T021,T022,T024,T025
- Work: Cover upload attacks, authorization, version immutability, failed upload cleanup, and document replacement.
- Acceptance: Replacement never silently changes assigned content; non-public access tests pass.
- Evidence / PR: Pending

## Epic 5: Assignments

### T027 — Implement assignment schema

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T013,T019
- Work: Create Assignment, AssignmentResource, and StudentAssignment with pinned lesson versions, timestamps, concurrency version, and uniqueness constraints.
- Acceptance: One progress row per assignment/student pair; intentional new assignments can reuse the same lesson.
- Evidence / PR: Pending

### T028 — Build assignment creation service

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T015,T024,T027
- Work: Implement class/selected-student assignment with current-enrollment validation, atomic creation, and duplicate-request protection.
- Acceptance: Retrying one request does not duplicate rows; deliberate reassignment creates new history; unauthorized recipients fail.
- Evidence / PR: Pending

### T029 — Build instructor assignment form

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T022,T025,T028
- Work: Add lesson version selection, recipient selection, instructions, optional documents, preview, and confirmation.
- Acceptance: Instructor can push without owner approval; class-wide means selected current students; duplicate click behavior is visible.
- Evidence / PR: Pending

### T030 — Implement assignment lifecycle

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T017,T028
- Work: Add cancellation/archive behavior, late-enrollment assignment action, and withdrawal handling.
- Acceptance: Late enrollment never silently receives prior lessons; cancelled records remain auditable and are excluded from active completion counts.
- Evidence / PR: Pending

### T031 — Test assignment integrity

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T029,T030
- Work: Add transaction, duplicate request, selected recipient, repeated lesson, transfer, and pinned-version tests.
- Acceptance: All assignment boundary and lifecycle tests pass; partial assignment creation is rolled back.
- Evidence / PR: Pending

## Epic 6: Progress and feedback

### T032 — Implement progress and feedback history

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T004,T027
- Work: Create ProgressEvent, attributed FeedbackEntry, and reusable AuditEvent storage; define retention/correction policy.
- Acceptance: Actor/time and before/after state are retained; instructor deactivation preserves attribution.
- Evidence / PR: Pending

### T033 — Implement progress transition service

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T015,T032
- Work: Implement assigned/in-progress/completed transitions, direct completion, reopen reason, and optimistic concurrency.
- Acceptance: Stale writes return conflicts; status and events commit together; students cannot invoke transitions; reopen reason is mandatory.
- Evidence / PR: Pending

### T034 — Implement feedback add/correction service

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T015,T032
- Work: Add attributed student-visible entries and auditable corrections according to policy.
- Acceptance: Users cannot silently overwrite another instructor entry; rendered feedback is safe; correction history remains available.
- Evidence / PR: Pending

### T035 — Build bulk progress workflow

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T033
- Work: Add selection preview, confirmation, per-record authorization, concurrency checks, and result reporting; choose explicit atomicity policy.
- Acceptance: Mixed unauthorized/stale selections behave exactly as documented; each committed student update has an event.
- Evidence / PR: Pending

### T036 — Build student detail and instructor progress grid

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T029,T033,T034,T035
- Work: Implement shared-instructor class grid, per-student class view, feedback, and progress actions.
- Acceptance: Two assigned instructors see shared updates; unrelated class history is not exposed; stale update conflicts are actionable.
- Evidence / PR: Pending

### T037 — Test progress concurrency and history

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T036
- Work: Add two-instructor conflict tests, direct-request student denial, reopen, bulk failure, and deactivated-actor history tests.
- Acceptance: No silent lost updates; no partial event/status commits; all mandatory permission cases pass.
- Evidence / PR: Pending

## Epic 7: Student experience and reporting

### T038 — Build student assignment dashboard

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T011,T027,T030
- Work: Implement only-current-student assignment list with kit, status, class, filters, and empty state.
- Acceptance: No other student records appear; no edit/submit/mark-complete controls exist.
- Evidence / PR: Pending

### T039 — Build student lesson view

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T022,T034,T038
- Work: Show pinned instructions, LEGO link, documents, progress, and feedback; keep logout/switch visible.
- Acceptance: Opening links or files never changes progress; unauthorized assignment IDs fail; external navigation behavior is documented.
- Evidence / PR: Pending

### T040 — Implement shared progress calculations

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T030,T033
- Work: Create centralized active-assignment completion queries and documented historical/current denominators.
- Acceptance: Cancelled records are excluded; zero assignments displays No lessons assigned; class metric weighting is explicit.
- Evidence / PR: Pending

### T041 — Build owner and instructor summaries

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T015,T036,T040
- Work: Create organization overview for owner and assigned-class summaries for instructors.
- Acceptance: Counts match shared queries; organization/global and class scope never mix; query counts are inspected.
- Evidence / PR: Pending

### T042 — Implement authorized CSV export

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T004,T040,T041
- Work: Export minimum approved student/class progress fields; apply filters, authorization, and spreadsheet formula-injection handling.
- Acceptance: Export matches visible authorized scope; unsafe cell prefixes are handled; export events are auditable.
- Evidence / PR: Pending

### T043 — Run browser and shared-device tests

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T037,T039,T041,T042
- Work: Test tablet layouts, keyboard use, empty/error states, back button, multiple tabs, logout, switching, and file handling.
- Acceptance: Tests distinguish application protections from browser/device policies; former student session cannot retrieve protected data.
- Evidence / PR: Pending

## Epic 8: Production readiness and release

### T044 — Complete administrative audit coverage

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T009,T014,T024,T028,T032,T042
- Work: Wire account, invitation, membership, lesson publish, assignment, progress, download/export where required, and configuration events into audit storage.
- Acceptance: Audit access is restricted; required mutations record actor/time/target; passwords and private tokens are absent.
- Evidence / PR: Pending

### T045 — Create staging and production deployment

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T003,T004,T020
- Work: Provision isolated app/database/private storage, TLS, secrets, email, migrations, and rollback runbook.
- Acceptance: Staging deploy succeeds from CI-controlled artifacts; production debug is off; secrets are not in artifacts.
- Evidence / PR: Pending

### T046 — Implement monitoring and operational alerts

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T044,T045
- Work: Configure request/error monitoring, health checks, failed login visibility, and backup/storage failure alerts.
- Acceptance: Synthetic failures reach the designated operator; logs exclude credentials and sensitive download tokens.
- Evidence / PR: Pending

### T047 — Implement database and document recovery

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T004,T045
- Work: Configure daily DB backups, document protection, retention, and a restore runbook with explicit proposed RPO/RTO.
- Acceptance: Recovery covers object content plus database references; credentials for restoration are controlled.
- Evidence / PR: Pending

### T048 — Execute isolated restore drill

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T047
- Work: Restore database and required documents into a separate environment and verify representative workflows.
- Acceptance: Recorded restore results include timing, data recovery point, accessible documents, and any deviations from targets.
- Evidence / PR: Pending

### T049 — Run security and capacity verification

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T018,T026,T031,T037,T043,T046,T045
- Work: Run full permission tests, dependency/configuration review, and representative 31-account concurrency test with approved synthetic data.
- Acceptance: Measured results and unresolved risks are recorded; do not label proposed performance as a measured guarantee.
- Evidence / PR: Pending

### T050 — Complete owner/instructor UAT

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T041,T042,T048,T049
- Work: Run essential/prime assignment, shared teaching, credential reset, progress, feedback, export, and shared-device scenarios.
- Acceptance: Owner signs off test results; material defects have fixes or explicit accepted exceptions.
- Evidence / PR: Pending

### T051 — Finalize center device and privacy procedures

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T004,T011,T022,T044
- Work: Document saved-password policy, device downloads cleanup, consent/retention decisions, user offboarding, and incident contacts.
- Acceptance: Operational owner is named; legal/consent questions are resolved or explicitly block launch; application limits are stated.
- Evidence / PR: Pending

### T052 — Launch and hand over

- [ ] Complete
- Status: `TODO`
- Owner: Unassigned
- Dependencies: T050,T051
- Work: Seed organization/classes, deliver staff training, verify backups/alerts, release, and monitor initial sessions.
- Acceptance: Go-live checklist approved; no default passwords remain; rollback owner and support contact are named.
- Evidence / PR: Pending

## Suggested first execution batch

1. Start T001 and T004.
2. After T001, parallelize T002, T003, and T005.
3. Prioritize T006 before account-dependent migrations.
4. Continue the identity/class track while private-storage and lesson work starts when its listed dependencies are satisfied.
5. Start staging, recovery, privacy, and device-procedure preparation before the classroom MVP is finished.

## Release blockers

- Staff MFA and recovery must be verified.
- Student session switching and cross-class authorization tests must pass.
- Document access must remain private and published assignment content stable.
- Concurrent progress updates must not silently overwrite each other.
- Restore drill must recover database records and supporting documents.
- Applicable privacy/consent decisions, retention policy, and center device procedures need explicit operational sign-off.
- Owner/instructor UAT must approve the release; unresolved material security defects block launch.
