---
name: robotics-lms-detailed-design
description: Generate an implementation-ready detailed design for a small LEGO Education robotics learning management system using confirmed requirements, explicit assumptions, traceable decisions, and testable acceptance criteria.
---

# Robotics LMS Detailed Design Skill

## Purpose
Act as a software architect and generate a detailed, implementation-ready design for the robotics LMS specified below. Treat this file as the requirements baseline and generation instructions, not as a completed technical design.

## Invocation
Use this skill when asked to generate, review, extend, or refine the detailed design of this LMS. Example: “Use robotics-lms-detailed-design to generate the complete design, including database schema, APIs, screens, authorization, and acceptance tests.”

Optional inputs: preferred technology stack, deployment provider, budget, document depth, authentication decision, instructor access policy, example lesson URLs, permitted document types, and existing source code or schema.

## Confirmed requirements
Assign these IDs in design traceability tables.

- FR-01: Serve one STEM organization with a STEM owner, five instructors, and 25 students. These are initial sizing figures, not permanent hard-coded limits.
- FR-02: Support three roles: STEM owner, instructor, student.
- FR-03: The STEM owner creates and manages instructor accounts.
- FR-04: Instructors create student accounts. Resolve existing student identities before creating duplicates.
- FR-05: Multiple instructors can teach the same students. Do not model a student as owned exclusively by one instructor.
- FR-06: Support LEGO Education SPIKE Essential through Grade 4 and SPIKE Prime for Grades 4–8. These are the organization's chosen grade bands, not claims about manufacturer recommendations. Grade 4 supports both; grade and kit remain separate attributes.
- FR-07: Lessons reference external LEGO lesson URLs. Do not assume a LEGO API, embedding permission, automatic completion synchronization, or robot-control integration.
- FR-08: Instructors can attach supporting documents and provide lesson instructions.
- FR-09: Instructors can push lessons directly to students without owner approval. Support class-wide and selected-student assignments as a proposed baseline, subject to confirmation.
- FR-10: Students see their assigned lessons, instructions, LEGO links, supporting documents, progress, and feedback.
- FR-11: Instructors exclusively manage progress and mark lessons complete. Opening a lesson does not change status. Students cannot change progress, submit work, or request review.
- FR-12: Instructor feedback is sufficient. Do not require grading, rubrics, student photo/video uploads, or code submissions.
- FR-13: Students use shared devices available only at the center. Do not assume individual devices or require student email addresses. Center-only usage does not by itself specify network-level access restriction.
- FR-14: Preserve individual student progress even when instructors share responsibility or students work together.

## Decisions not yet confirmed
Keep these visible in a decision register. Never present them as user-approved.

- D-01 Student access: individual student credentials versus an instructor-started classroom session with student selection. A name picker alone is not individual authentication. Explain privacy, switching, and authorization implications of each mode.
- D-02 Instructor scope: all 25 students versus only students in classes assigned by the owner.
- D-03 Classroom structure: class definitions, number of classes, terms, and enrollment rules.
- D-04 Access boundary: center-only intended usage versus actual center-network restriction. Do not infer IP restrictions or geofencing.
- D-05 Documents: file types, maximum sizes, visibility, retention, malware inspection, and replacement/version behavior.
- D-06 Lesson editing: shared lesson ownership, modification permissions, assignment snapshots/versioning, and duplicate URL handling.
- D-07 Operational constraints: implementation stack, hosting, budget, recovery targets, retention, and applicable consent/privacy obligations.

Ask at most five high-impact clarification questions in one batch if interaction is available. If answers are unavailable or the user requests immediate generation, proceed with explicitly labeled provisional assumptions and show how each open decision affects the design. Do not stop at questions.

## Provisional design baseline
Use only where needed and label as proposed rather than confirmed:

- A single web application, one relational database, and private document storage.
- Classes with many-to-many instructor membership and student enrollment.
- Owner organization-wide access; instructors limited to assigned classes.
- Owner manages classes and instructor membership.
- Individual student credentials without mandatory email, pending D-01.
- Student assignment statuses: ASSIGNED, IN_PROGRESS, COMPLETED. Cancellation, reopening, and administrative correction require explicit rules and history.
- Per-student assignment records and append-only progress/feedback history.
- Shared lesson records plus version-pinned content or assignment snapshots; justify the selected approach.
- No mandatory owner approval for instructor lesson creation or assignment.
- No microservices, Kubernetes, event streaming, AI tutor, payments, parent portal, offline synchronization, or direct LEGO hardware integration in the MVP.
- Reports and CSV export are optional proposed features, not confirmed requirements.

## Required generation workflow

1. Restate confirmed scope and distinguish requirements, assumptions, recommendations, and unresolved decisions.
2. Resolve or register consequential access and identity decisions before committing to a permission model.
3. Select and justify a proportionate architecture; prefer existing organizational stack if supplied.
4. Define workflows and state transitions before finalizing entities and APIs.
5. Make the permission matrix, schema, API contracts, screens, and tests mutually consistent.
6. Trace every confirmed requirement to design elements and acceptance tests.
7. Review for shared-device leakage, horizontal privilege escalation, duplicate students, concurrent instructor edits, and progress-history loss.
8. Deliver the requested detail, not only a high-level outline. If the output must be split, provide a section manifest and clearly identify incomplete parts.

## Detailed design output contract

### 1. Executive summary and scope
Include goals, actors, confirmed scale, in-scope capabilities, exclusions, assumptions, open decisions, and a numbered requirements catalog using FR IDs.

### 2. Architecture and deployment
Provide a component diagram, responsibilities, trust boundaries, data flow, deployment topology, environment separation, configuration/secrets approach, and deployment/rollback process. Mermaid diagrams are acceptable when supported; otherwise use text diagrams. Distinguish architecture choices from vendor facts.

Recommend a single application unless new requirements justify more complexity. Size for one owner, five instructors, and 25 students; propose testing all 31 active concurrently. Performance and availability numbers must be labeled proposed targets until approved and measured.

### 3. Identity, sessions, and authorization
Provide a role/action/resource permission matrix and server-side authorization rules. Specify organization, class, student, assignment, and document scopes. Handle inactive accounts, password/reset or alternative credential lifecycle, staff authentication, and student account creation.

For shared devices, detail login, student switching, logout, inactivity handling, browser back navigation, cache behavior, attachment access, and leaving the LMS for a LEGO link. Distinguish LMS session termination from behavior of an external site. Do not expose rosters or progress outside the chosen access policy. If selecting classroom-session mode, document its exact trust model instead of claiming students are individually authenticated.

### 4. Domain model and database
Provide an ER diagram, entity descriptions, field-level data dictionary, primary/foreign keys, nullability, uniqueness, constraints, indexes, timestamps, and lifecycle/deletion rules. Include executable schema or migrations for the chosen database when full implementation detail is requested.

Cover at least Organization, User, Class, ClassInstructor, Enrollment, Lesson, LessonVersion or AssignmentSnapshot, LessonResource, Assignment, StudentAssignment, FeedbackEntry, ProgressEvent, and AuditEvent. Additional entities require justification. Document how actor, student, and class relationships prevent cross-scope access.

Separate reusable lessons from assignments and per-student progress. Specify how documents are pinned to versions or assignments. Define the uniqueness boundary for a student assignment without blocking intentional reassignment of the same lesson.

### 5. Lesson and assignment lifecycle
Specify lesson registration by URL, kit/grade tagging, instructor instructions, supporting documents, sharing and editing permissions, assignment creation, recipient selection, and publication visibility.

Define behavior for late enrollment, withdrawal, student transfer, duplicate assignment clicks, intentional reassignment, archived lessons, broken external links, modified source lessons, deleted/replaced documents, and instructor deactivation. Historical assignments must have defined behavior rather than silently disappearing.

### 6. Progress and feedback
Give a state transition table with actor permissions, validation, timestamps, side effects, audit events, and error cases. Students have read-only progress access. Instructors can complete directly if permitted, reopen with a reason, and add attributed feedback.

Specify feedback visibility, edit/correction policy, concurrency control, transaction boundaries, and safe bulk updates. Explain whether bulk operations are atomic or permit partial success. Preserve correction history. Derive completion percentage from active assigned records; define the denominator, cancelled records, and the no-assignments display. Do not treat external-link clicks as learning completion.

### 7. API or server-action contracts
Match the chosen architecture: server actions/form handlers are acceptable instead of a separate REST service. For each externally callable operation provide method/route or action name, authorization, request schema, response, validation, status/error codes, audit behavior, concurrency, and idempotency where relevant.

Cover accounts, class membership, lessons, resources, assignments, student lesson view, progress updates, feedback, and dashboard queries. Include representative JSON or form examples. Never rely on client-supplied role, organization, or instructor IDs as trusted authorization context. Include pagination/filtering where applicable.

### 8. User experience
Describe screens, navigation, actions, empty/loading/error states, keyboard/touch behavior, and role visibility. Include text wireframes for owner dashboard, instructor roster, lesson editor, assignment form, progress grid, student dashboard, and lesson detail. Student screens contain no submit, review-request, or mark-complete actions.

Make switching students and logging out explicit on shared devices. Distinguish Essential and Prime without relying solely on color. Grade 4 must support either kit.

### 9. Document handling and external links
Define authorized upload/download flows, private object keys, filename and size validation, MIME/content validation, permitted types, inspection policy, download authorization, retention, and orphan cleanup. Define whether expiring links are used and their limitations on shared devices.

External URLs must be validated according to a documented policy. Do not scrape, redistribute, embed, or claim usage rights to LEGO content without verification. Avoid server-side fetching unless explicitly designed and protected. Specify broken-link handling without inventing a LEGO integration.

### 10. Security, privacy, and operations
Provide a threat-focused checklist for shared devices, object-level authorization, session misuse, malicious uploads, script injection, cross-site requests, and accidental student disclosure. Address minimum student data, consent decisions, retention/deletion, secrets, encryption, logs, and sensitive-data handling. Do not claim legal compliance from architecture alone.

Define proposed service targets, backup and restore process, recovery objectives, monitoring, alerts, audit access, and incident response. Separate database backups from attachment recovery. State who verifies a restore and how.

### 11. Test and acceptance plan
Provide concrete Given/When/Then tests mapped to FR IDs. Include positive, negative, concurrent, lifecycle, shared-device, document-access, and recovery cases.

Mandatory scenarios:
- Two authorized instructors can update the same student's records without silently losing changes.
- An unauthorized instructor cannot access a student or document by changing an ID.
- A student cannot change progress through UI or direct requests.
- Switching students does not reveal the previous student's data through retained session/UI state.
- Opening LEGO links does not mark completion.
- A Grade 4 student can receive either kit's lesson.
- Duplicate assignment requests do not accidentally duplicate progress.
- Reassigning a lesson intentionally retains earlier history.
- Instructor deactivation preserves attributed feedback and progress.
- Document replacement follows the chosen version policy.
- Bulk progress updates have defined failure and audit behavior.
- A backup restore recovers both required records and accessible document references.

### 12. Delivery plan and traceability
Provide sequenced implementation milestones, dependencies, MVP cut line, risks and mitigations, decision register, and a requirement-to-component/API/test traceability matrix. Estimates must be labeled estimates and state staffing and scope assumptions. Do not invent costs or delivery commitments.

## Evidence and quality rules
- The confirmed requirements above are user-provided project decisions and need no external citation.
- Verify current vendor capabilities, technology versions, licensing, LEGO integration claims, legal statements, hosting prices, or other external factual claims using available authoritative sources. If verification is unavailable, identify the claim as unverified or omit it.
- Do not silently convert provisional defaults into confirmed requirements.
- Avoid scope expansion, unnecessary infrastructure, invented integrations, or unsupported compliance claims.
- Keep names, status values, permission scopes, schema, endpoints, diagrams, and examples consistent throughout.
- End with a concise list of decisions requiring owner approval, not a generic offer to continue.

## Completion checklist
- [ ] All FR-01 through FR-14 requirements are covered and traced.
- [ ] Open identity and instructor-scope decisions are explicit.
- [ ] Grade 4 supports both kits.
- [ ] Multiple instructors share student records under a defined scope.
- [ ] Students cannot change progress or submit work.
- [ ] Shared-device session and data-isolation behavior is defined.
- [ ] Lesson links and supporting documents have separate lifecycle rules.
- [ ] Concurrent edits, reassignment, and audit history are addressed.
- [ ] Database, permissions, APIs/actions, screens, and tests agree.
- [ ] Performance, recovery, costs, and schedules are not presented as measured guarantees.
